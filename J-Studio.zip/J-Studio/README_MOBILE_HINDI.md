# J Studio — Android Cloud Build starter

यह प्रोजेक्ट आपके भेजे हुए `JDelayStudio_Offline_Stereo.html` को Android WebView ऐप के अंदर चलाता है और माइक्रोफोन permission संभालता है। यह अभी **starter/prototype** है, पूर्ण native low-latency audio engine नहीं। असली फोन पर audio latency, stereo input/output और recording को टेस्ट करना जरूरी है।

## मोबाइल से APK बनाना (लैपटॉप नहीं चाहिए)
1. इस ZIP को extract करने की जरूरत नहीं: GitHub वेबसाइट पर नया खाली repository बनाएं और इस ZIP की सामग्री अपलोड करें। ZIP के अंदर की फाइलें repository के root में जानी चाहिए; ZIP फाइल को अकेले upload करने से workflow नहीं चलेगा।
2. Repository में `.github/workflows/android.yml` मौजूद होनी चाहिए।
3. GitHub में **Actions** tab खोलें → **Build J Studio APK** → **Run workflow**.
4. Build सफल होने पर उसी workflow run के नीचे **Artifacts** में `J-Studio-debug-apk` डाउनलोड करें। ZIP artifact के अंदर `app-debug.apk` होगा।

## सीमाएं
- यह debug APK होगा, Play Store release/signed production APK नहीं।
- WebView/Web Audio की latency Android device, browser engine और audio route पर निर्भर करेगी; zero-latency का दावा नहीं है।
- Bluetooth monitoring में noticeable delay हो सकता है; wired headphones/interface से जांचें।
- Stereo microphone capture/output device-specific है; app में दिखने वाले L/R controls अपने-आप hardware true-stereo guarantee नहीं करते।
- 2290/Tape presets अभी parameter presets हैं, पूर्ण modeled hardware algorithms नहीं।
